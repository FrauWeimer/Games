# python-tictactoe
A game based on "TicTacToe" in the Python programming language using the Turtle library.

Some code is taken from this author:
https://github.com/AlejoG10/python-tictactoe-yt#readme
